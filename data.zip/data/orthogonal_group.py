"""
Adapted from https://github.com/JamesBrofos/Manifold-Dequantization
"""

import jax.numpy as jnp
import jax.scipy.special as jspsp
from jax import random
from jax import vmap
import numpy as np


def uqr(A: jnp.ndarray):
    """This is the implementation of the unique QR decomposition as proposed in
    [1], modified for JAX compatibility.
    [1] https://github.com/numpy/numpy/issues/15628
    Args:
        A: Matrix for which to compute the unique QR decomposition.
    Returns:
        Q: Orthogonal matrix factor.
        R: Upper triangular matrix with positive elements on the diagonal.
    """
    Q, R = jnp.linalg.qr(A)
    signs = 2 * (jnp.diag(R) >= 0) - 1
    Q = Q * signs[jnp.newaxis]
    R = R * signs[..., jnp.newaxis]
    return Q, R


def sample_haar_on(rng: random.PRNGKey, num_samples: int, num_dims: int) -> jnp.ndarray:
    """Draw samples from the uniform distribution on the O(n).
    Args:
        rng: Pseudo-random number generator seed.
        num_samples: Number of uniform samples to generate.
        num_dims: Dimensionality of the matrix
    Returns:
        q: A matrix of uniformly distributed elements on O(n).
    """
    xo = random.normal(rng, [num_samples, num_dims, num_dims])
    q, r = vmap(uqr)(xo)
    return q


def logpdf_haar_on(xon: jnp.ndarray) -> float:
    """Computes the log-density of the uniform distribution on O(n). This is the
    negative logarithm of the volume of O(n), which is twice the volume of
    SO(n).
    Args:
        xon: The observations on O(n) at which to compute the uniform density.
    Returns:
        logpdf: The log-density of the uniform distribution on O(n).

    https://math.stackexchange.com/questions/1364495/haar-measure-on-son

    log Vol(Vn) = n log(pi) / 2 - loggamma(n/2 + 1)
    log Vol(Sn) = log(2pi) + log Vol(Vn-1)
                = log(2) + (n+1) log(pi) / 2 - loggamma((n+1)/2)
    log Vol(SOn) = sum_{i=1}^{n-1} log Vol(Sn)
                 = (n-1) * log(2) + (n-1) * (n+2) * log(pi) / 4 -
                   sum_{i=1}^{n-1} loggamma((i+1)/2)
    """
    num_dims = xon.shape[-1]
    logvol = (
        jnp.log(2.) + (num_dims-1) * jnp.log(2.) +
        (num_dims - 1)*(num_dims + 2) / 4. * jnp.log(jnp.pi) -
        jspsp.gammaln(jnp.arange(2, num_dims + 1) / 2).sum())
    logpdf = -logvol
    return logpdf * jnp.ones(xon.shape[:-2])


def sample_haar_son(rng: random.PRNGKey, num_samples: int, num_dims: int) -> jnp.ndarray:
    samples_on = sample_haar_on(rng, num_samples, num_dims)
    return samples_on * jnp.linalg.det(samples_on)[..., jnp.newaxis, jnp.newaxis]


def logpdf_haar_son(xon: jnp.ndarray) -> float:
    return logpdf_haar_on(xon) + jnp.log(2)


def log_unimodal(x: jnp.ndarray) -> jnp.ndarray:
    """Unimodal distribution on O(n) centered at the identity matrix."""
    num_dims = x.shape[-1]
    Id = jnp.eye(num_dims)
    lp = -0.5 * jnp.square(x - Id).sum(axis=(-1, -2))
    lp = lp / 0.5
    return lp


def log_multimodal(x):
    """Multimodal distribution on O(n) with components centered at the identity
    matrix and the pure reflection.
    """
    Id = jnp.eye(3)
    Ra = jnp.diag(jnp.array([-1., -1., 1]))
    Rb = jnp.diag(jnp.array([-1., 1., -1]))
    scale = 0.5
    lp = 0.
    lp += jnp.exp(-0.5 * jnp.square(x - Id).sum((-1, -2)) / jnp.square(scale))
    lp += jnp.exp(-0.5 * jnp.square(x - Ra).sum((-1, -2)) / jnp.square(scale))
    lp += jnp.exp(-0.5 * jnp.square(x - Rb).sum((-1, -2)) / jnp.square(scale))
    return jnp.log(lp)


if __name__ == '__main__':
    log_dens = log_multimodal
    rng_son, rng_u = random.split(random.PRNGKey(12345), 2)
    xhaar = sample_haar_son(rng_son, 5000000, 3)
    lprop = logpdf_haar_son(xhaar)
    ld = log_dens(xhaar)
    la = ld - ld.max() - 0.5
    logu = jnp.log(random.uniform(rng_u, [len(xhaar)]))
    xobs = xhaar[logu < la]
    print('number of rejection samples: {}'.format(len(xobs)))
    assert jnp.all(la < 0.)

    np.save('orthogonal_group.npy', np.asarray(xobs)[:50000])
