from torch.utils.data import Dataset
import numpy as np
import pandas as pd
from utils.utils import sample_2d_uniform_patch
import manifold
from lorentz import Lorentz
from wrappednormal import WrappedNormal
import torch
import os


def get_split(data, split, seed):
    assert split in ['train', 'valid', 'test', 'all'], f'split {split} not supported.'
    if split != 'all':
        rng = np.random.default_rng(seed)
        indices = np.arange(len(data))
        rng.shuffle(indices)

        n = len(data)
        if split == 'train':
            data = data[indices[:int(n * 0.8)]]
        elif split == 'valid':
            data = data[indices[int(n * 0.8):int(n * 0.9)]]
        elif split == 'test':
            data = data[indices[int(n * 0.9):]]
    return data


class Dragonfly(Dataset):

    def __init__(self, path='data/dragonfly.npy', split='train', seed=12345):
        data = np.load(path).astype('float32')
        self.data = get_split(data, split, seed)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]


class Top500(Dataset):

    def __init__(self, root='data/top500', amino='General', split='train', seed=12345):
        data = pd.read_csv(f'{root}/aggregated_angles.tsv',
                           delimiter='\t',
                           names=['source', 'phi', 'psi', 'amino'])

        amino_types = ['General', 'Glycine', 'Proline', 'Pre-Pro']
        assert amino in amino_types, f'amino type {amino} not implemented'

        data = data[data['amino'] == amino][['phi', 'psi']].values.astype('float32')
        self.data = get_split(data, split, seed) % 360

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]


class RNA(Dataset):

    def __init__(self, root='data/rna', split='train', seed=12345):
        data = pd.read_csv(f'{root}/aggregated_angles.tsv',
                           delimiter='\t',
                           names=['source', 'base', 'alpha', 'beta', 'gamma', 'delta', 'epsilon', 'zeta', 'chi'])

        data = data[['alpha', 'beta', 'gamma', 'delta', 'epsilon', 'zeta', 'chi']].values.astype('float32')
        self.data = get_split(data, split, seed) % 360

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]


class UniformPatchDataset(Dataset):
    def __init__(self, n: int = 50000):
        self.n = n
        self.data = manifold.Sphere.invphi(sample_2d_uniform_patch(n)).data.numpy()

    def __len__(self):
        return self.n

    def __getitem__(self, idx):
        return self.data[idx]


class Earth(Dataset):
    def __init__(self, root='data/earth_data', event='volcano', split='train', seed=12345):
        """https://arxiv.org/pdf/2202.02763.pdf"""

        event_types = ['volcano', 'earthquake', 'flood', 'fire']
        assert event in event_types, f'event type {event} not implemented'

        path = f'{root}/{event}.csv'
        data = pd.read_csv(path).to_numpy().astype('float32')

        lat = data[:, 0:1] / 360 * np.pi * 2
        lon = data[:, 1:2] / 90 * np.pi / 2

        self.data = get_split(np.concatenate([np.cos(lat) * np.cos(lon), np.cos(lat) * np.sin(lon), np.sin(lat)], 1),
                              split, seed)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]


def generate_hyperbolic_synth(data_dir='data', dataset_len=50000, dataset='1wrapped'):
    """Samples from the distribution given by dataset"""
    n_samples = dataset_len
    z = torch.randn(n_samples, 2)
    M = Lorentz()
    device = torch.device("cpu")
    if dataset == '1wrapped':
        mu = torch.Tensor([-1., 1.]).unsqueeze(0)
        std_v = .75
        std_1 = torch.Tensor([[std_v], [std_v]]).T
        mu_h = M.exp0(M.unsqueeze_tangent(mu))
        distr = WrappedNormal(device, M, mu_h, std_1)
        samples = distr.rsample((n_samples,)).squeeze()
        dataset_name = 'hyper_synth_' + dataset
        np.save(os.path.join(data_dir, dataset_name), samples.numpy())

    elif dataset == 'euc_5gaussians':
        scale = 3
        z = z / 2
        centers = [(1, 0), (-1, 0), (0, 1), (0, -1), (0, 0)]
        centers = torch.tensor([(scale * x, scale * y) for x, y in centers])
        samples = z + centers[torch.randint(len(centers), size=(n_samples,))]
        dataset_name = 'hyper_synth_' + dataset
        np.save(os.path.join(data_dir, dataset_name), samples.numpy())

    elif dataset == '5gaussians':
        scale = 3
        z = z / 4
        centers = [(1, 0), (-1, 0), (0, 1), (0, -1), (0, 0)]
        centers = torch.tensor([(scale * x, scale * y) for x, y in centers])
        samples = z + centers[torch.randint(len(centers), size=(n_samples,))]
        # transform to Lorentz
        threedim = M.unsqueeze_tangent(samples)
        samples = M.exp0(threedim)
        dataset_name = 'hyper_synth_' + dataset
        np.save(os.path.join(data_dir, dataset_name), samples.numpy())

    elif dataset == 'bigcheckerboard':
        s = 1.5  # side length
        offsets = [(0, 0), (0, -2 * s), (s, s), (s, -s), (-s, s), (-s, -s), (-2 * s, 0), (-2 * s, -2 * s)]
        offsets = torch.tensor([o for o in offsets])

        # (x,y) ~ uniform([0,s] \times [0,s])
        x1 = torch.rand(n_samples) * s
        x2 = torch.rand(n_samples) * s

        samples = torch.stack([x1, x2], dim=1)
        samples = samples + offsets[torch.randint(len(offsets), size=(n_samples,))]
        # transform to Lorentz
        threedim = M.unsqueeze_tangent(samples)
        samples = M.exp0(threedim)
        dataset_name = 'hyper_synth_' + dataset
        np.save(os.path.join(data_dir, dataset_name), samples.numpy())

    elif dataset == 'mult_wrapped':
        s = 1.3
        centers = [torch.tensor([[0., s, s]]), torch.tensor([[0, -s, -s]]),
                   torch.tensor([[0., -s, s]]), torch.tensor([[0, s, -s]])]
        centers = [M.projx(center) for center in centers]
        n = n_samples // len(centers)
        var1 = .3
        var2 = 1.5
        scales = [torch.tensor([[var1, var2]]), torch.tensor([[var1, var2]]),
                  torch.tensor([[var2, var1]]), torch.tensor([[var2, var1]])]

        distrs = []
        for i in range(len(centers)):
            loc = centers[i]
            scale = scales[i]
            distrs.append(WrappedNormal(device, M, loc, scale))
        samples = distrs[0].rsample((n,))
        for distr in distrs[1:]:
            samples = torch.cat([samples, distr.rsample((n,))], dim=0)
        samples = samples.squeeze()
        dataset_name = 'hyper_synth_' + dataset
        np.save(os.path.join(data_dir, dataset_name), samples.numpy())
        return samples


class HyperbolicSynthDataset(Dataset):
    def __init__(self, data_dir='data/', device='cuda',
                 dataset='1wrapped', split='train', seed=12345):
        """
        Args:
            data_dir (string): Directory to generate or load data from.
        """
        dataset_name = 'hyper_synth_' + dataset + '.npy'
        dataset_path = os.path.join(data_dir, dataset_name)

        # generate data if does not exist
        if not os.path.exists(dataset_path):
            generate_hyperbolic_synth(dataset=dataset)

        data = np.load(dataset_path)
        self.data = torch.tensor(data, dtype=torch.float32).to(device)
        self.data = torch.Tensor(get_split(data, split, seed))
        # transform to Lorentz
        # if 'euc' not in dataset_name:
        # self.data = M.to_poincare(self.data)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        if torch.is_tensor(idx):
            idx = idx.tolist()

        return self.data[idx]


class SpecialOrthogonalGroup(Dataset):

    def __init__(self, root='data', split='train', seed=12345):
        data = np.load(f'{root}/orthogonal_group.npy').astype('float32')
        self.data = get_split(data, split, seed)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]
